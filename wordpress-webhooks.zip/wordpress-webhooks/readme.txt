=== WP Webhooks Pro ===
Author URI: https://ironikus.com/
Plugin URI: https://ironikus.com/downloads/wp-webhooks-pro/
Contributors: ironikusagency
Donate link: https://paypal.me/ironikus
Tags: webhooks, automation, ironikus, webhook, wp webhooks, create user
Requires at least: 4.7
Tested up to: 5.5.3
Stable Tag: 3.1.1
License: GNU Version 3 or Any Later Version

Extend your website with the most powerful webhook system.

== Description ==

This plugin extends your WordPress website by turning it into a powerful webhook system to send and receive data on and from your site.
This enables you to set up various actions and triggers like for example adding a user, deleting a user an much more.
It is also possible to create your very own webhook functionality using our optimized webhooks. 
For a list of all features, please checkout the feature list down below:

= Features =

* Create, Delete Update, Search and Retrieve users via external webhooks on your website
* Add, update and delete user meta on all of the user action webhooks
* Add and/or remove multiple user roles on user update/create
* Create, Delete Update, Search and Retrieve posts via external webhooks on your website
* Add, update and delete post meta on all of the user action webhooks
* Receive data to a custom webhook action (Do whatever you want with the incoming data)
* Send data on login, register, update, new post, update post and more
* Send data on custom WordPress hook calls
* Bulk-send multiple webhooks within a single webhook call
* Use your website to reformat other webhook requests (Your website will validate data and routes through the request)
* Authenticate every "Send data" trigger. Supported are: API Key, Bearer Token and Basic Auth
* Add multiple webhooks for each trigger and also for the actions
* Use data mapping to fit your incoming or outgoing data to WP Webhooks Pro
* Test all of the available triggers with a single click
* Advanced settings for each webhook trigger url
* Log functionality for all incoming and outgoing actions actions and triggers
* Enhanced security through ip whitelists, webhook action token, unsafe URL rejection and SSL verification
* Free premium extensions available
* Manage all of our extensions within the plugin
* Fully translatable and ready for multilingual sites
* Full WPML Support
* Whitelabel feature for Unlimited licenses
* Advanced Developer Hooks
* Optimized settings page for more control
* Supports XML, JSON, plain text/HTML and form urlencode
* Supports the following request methods: POST (Default), GET, HEAD, PUT, DELETE, TRACE, OPTIONS, PATCH
* Supports Zapier, Integromat, automate.io and more

= Free Extensions =
On wordpress.org you will also find more free extensions to equip your favorite plugins via webhooks.
* [WP Webhooks – Easy Digital Downloads](https://wordpress.org/plugins/wp-webhooks-easy-digital-downloads/)
* [Contact Form 7 Integration](https://wordpress.org/plugins/wpwh-contact-form-7/)
* [Manage Taxonomy Terms](https://wordpress.org/plugins/wp-webhooks-manage-taxonomy-terms/)
* [WP Reset Integration](https://wordpress.org/plugins/wpwh-wp-reset-webhook-integration/)
* [WP Webhook Comments](https://wordpress.org/plugins/wp-webhooks-comments/)
* [WP Webhooks – Email integration](https://wordpress.org/plugins/wp-webhooks-email-integration/)

= For devs =

Feel free to message us in case you want special features - We love to help!

== Installation ==

1. Activate the plugin
2. Go to Settings > WP Webhooks Pro and include your license.
3. Activate your license and you are ready to automate!
4. You will find the menu item under Settings > WP Webhooks Pro


== Changelog ==

= 3.1.1: November 12, 2020 =
* Fix: Data Mapping with old templates contained a compatibility issue causing the mapped value fields to be empty
* Fix: Missing description for user_delete webhook trigger $user object

= 3.1.0: November 06, 2020 =
* Feature: Full ACF support for create_post, update_post, create_user, update_user webhook actions (New argument manage_acf_data)
* Feature: Completely reworked meta functionality for create_post, update_post, create_user, update_user webhook actions (New argument manage_meta_data)
* Feature: Add post meta data to get_posts webbhook action as a separate argument (load_meta)
* Feature: Added the possibility to serialize and JSON encode a value within the data mapping template (Added within the "Format Value" setting)
* Feature: Create multi-level data payloads within your data mapping template for webhook triggers (Send Data) - (Set a JSON as the value and select JSON Decode within the Format value setting)
* Feature: New webhook action (bulk_webhooks) - It allows you to send multiple webhook requests within a single webhook call. It supports internal and external URLs and is fully compatible will all features of WP Webhooks
* Tweak: correct webhook response grammar mistakes
* Tweak: Optimize Data Mapping Key Settings Descriptions
* Tweak: Optimize the data mapping description
* Tweak: Optimize webhook action responses for create_user, update_user, create_post, update_post
* Tweak: Deprecated argument meta_input on create_post and update_post webhook actions (It's backwards compatible)
* Tweak: Deprecated argument user_meta on create_user and update_user webhook actions (It's backwards compatible)
* Tweak: Optimize the functionality on the create_post action setting for firing on the initial post status change
* Tweak: Correct wrong texts all over the plugin
* Tweak: As of the WP 5.5 release, the $user object is sent over with the deleted_user hook: https://developer.wordpress.org/reference/hooks/deleted_user/ - We made the new variable compatible
* Fix: A notice appeared due to a string validation on an object for the deprecated user_meta argument
* Fix: The create_post webhook action in combination with firing on the post status change, caused the post not to be triggered on a post update
* Fix: Correct wrongly assigned nickname variable check on the create_user and update_user webhook actions
* Fix: Correct notice with indefined variable within the webhook action logic
* Fix: PHP warning: SimpleXMLElement::addChild() expects parameter 2 to be string, object given - It occured within the convert_to_xml() function and is now fixed
* Fix: In some cases, the data value, within data mapping templates, was not decoded if the value format was chosen after the JSON Decode setting was activated and saved 
* Fix: On some JSON decode and unserialize excutes within the data mapping template for the "Format value" settings, the data was not unserialized/decoded if there was no mapping keys defined after - it also threw a PHP notice 
* Dev: New helper class to check if a given plugin is installed ( is_plugin_installed() )
* Dev: New helper class to check if a given plugin is active ( is_plugin_active() )

= 3.0.7: September 22, 2020 =
* Tweak: Add import_id to the create_post webhook action
* Tweak: Added permalink to the following triggers: post_create, post_update, post_delete and post_trash
* Fix: Correct naming for data mapping setting
* Dev: Introduced new handler function echo_action_data() to centralize the output of a webhook action
* Dev: Extend the ww/webhooks/response_response_type filter by a new argument: $args (https://ironikus.com/docs/knowledge-base/filter-response-type/)
* Dev: The echo_response_data() function now returns the validated data as well

= 3.0.6: July 01, 2020 =
* Feature: Fully reworked data mapping engine with tons of new features (It's backwards compatible, of course): https://ironikus.com/docs/knowledge-base/how-to-use-data-mapping/
* Feature: Data Mapping template can now control which keys are send within the payload. This way you can control the size of the outgoing data
* Feature: Data Mapping dynamic tags can now be used for both keys and values
* Feature: New Data Mapping setting to unserialize a serialized array or object
* Feature: Set a Fallback value for Data Mapping Keys and values
* Feature: Data Mapping keys and values can not be formatted to string, integer, bool, float and null
* Feature: Whitelabel feature for WP Webhooks Pro: (https://ironikus.com/docs/knowledge-base/whitelabel-wp-webhooks-pro/)
* Tweak: Optimized layout
* Tweak: Correct comments
* Tweak: Strip slashes from data mapping templates
* Tweak: Optimized licensing error messages
* Tweak: Correct variable naming for map_data_to_template() of $webhook_type 
* Tweak: Revalidate JSON within the JSON string to encode certain characters
* Fix: Attempt to assign property of non-object - is now fixed for the data mapping feature
* Fix: Issue with wrong naming for the "Send Data" setup on the demo user payload for the user_meta key
* Dev: get_response_body() helper now supports manual data entry as a payload and content type
* Dev: New filter: ww/settings/data_mapping_template_settings (https://ironikus.com/docs/knowledge-base/filter-data-mapping-template-settings/)
* Dev: New filter: ww/settings/data_mapping_key_settings (https://ironikus.com/docs/knowledge-base/filter-data-mapping-key-settings/)
* Dev: wordpress_webhooks()->license->update() accepts now custom attributes as well

= 3.0.5: July 01, 2020 =
* Feature: Add user meta to the get_user webhook action
* Feature: Added trigger response data to the log feature and some further data optimizations
* Feature: The custom_action trigger got a rework and now uses apply_filters() instead of do_action - this allows you to also catch the response (the logic is backwards compatible, so you can still continue to use your existing logic)
* Feature: Allow modification of the http arguments within the custom_action webhook action (separate variable for the apply_filters() call)
* Feature: Allow the percentage character within webhook trigger URLs
* Feature: Add separate object and array array serialization to the user/post meta data (Applicable for the following webhook actions: create_user, update_user, create_post, update_post)
* Feature: Add user meta data to the get_users webhook action response
* Feature: New trigger setting to allow unsafe looking URLs (By default, URL's like asiufgasvflhsf.siugsf.com are prevented from being sent for your security)
* Feature: New trigger setting to allow unverified SSL connections (In case you have a self-signed URL, you can prevent the default SSL check for each webhook)
* Feature: New data mapping action for decoding a JSON string within the webhook response to make each entry accessible
* Tweak: Optimized log layout
* Tweak: Optimized data structure for the log feature
* Tweak: Optimize PHPDocs
* Fix: The same webhook names for different triggers broke the settings popup
* Fix: the delete_post webhook action contained a wrongly formatted error message
* Fix: Prevalidate json within the is_json() helper function to prevent notices within the debug.log file
* Dev: Added the trigger group slug to the ww/admin/settings/webhook/page_capability filter (currently the trigger was only sent by its name which is not unique without the trigger group)
* Dev: Added new handler function for generating the API keys
* Dev: New filter to manipulate the API key: ww/admin/webhooks/generate_api_key (https://ironikus.com/docs/knowledge-base/filter-generated-api-key-for-action-urls/)

= 3.0.4: May 11, 2020 =
* Feature: New webhook trigger that sends data on trashing a post (custom post types supported)
* Feature: The tax_input argument for create_post/update_post actions now supports JSON formatted strings
* Feature: Added taxnomies as well to post_delete trigger
* Feature: Added full post thumbnail URL to the post_create, post_update and post_delete trigger
* Feature: Extend demo data for post_create, post_update and post_delete trigger
* Feature: Add digest authentication for authentication templates
* Tweak: Added the already existing parameters to the parameter description of the post_delete trigger
* Tweak: Optimized all webhook descriptions and texts
* Tweak: Remove test array from extensions ajax feedback
* Tweak: Optimize layout for the webhook action argument list
* Fix: Taxonomies haven't been sent over on post_create and post_update trigger

= 3.0.3: March 17, 2020 =
* Feature: EXTENSION MANAGEMENT - You can now manage all extensions for WP Webhooks and WP Webhooks Pro within our plugin via a new tab (Install, Activate, Deactivate, Upgrade, Delete)
* Feature: Whitelist webhook actions for single webhooks - This allows you to restrict the access of webhooks actions for single webhook action URL's
* Feature: the arguments post_date and post_date_gmt on the create_post/update_post webhook actions accept now any kind of date format (we automatically convert it to Y-m-d H:i:s)
* Feature: Introducton to a new settings item called "Activate Debug Mode" - It will provide further debug.log information about malformed data structures and more
* Tweak: Repositioning of the logging feature for incoming webhooks AFTER the webhook token authentication
* Tweak: Remove post_modified and post_modified_gmt parameter from the create_post webhook action since they are non-functional (https://core.trac.wordpress.org/ticket/49767)
* Tweak: Support for meta data for attachments on create_post and update_post webhook actions
* Tweak: Reposition fetching of the action parameter for incoming webhook requests
* Tweak: Optimized layout for the plugin admin area
* Tweak: Optimize webhook action response text in case there wasn't any action defined
* Fix: create_if_none bug on update_post webhook cation (In case a post ID was given and there was no post related to it, a post was still created, even without defining the create_if_none argument)
* Dev: Add new helper function to check if a plugin is installed

= 3.0.2: March 29, 2020 =
* Feature: Full reworked webhook descriptions (You WILL love them!)
* Feature: Add user data and user meta as well to the deleted_user trigger
* Tweak: Optimized tab descriptions
* Tweak: Optimized stylings
* Tweak: Add post details + meta as well for attachment deletions
* Fix: Post details + meta haven't been available on the post_delete trigger
* Fix: Prevent custom HTML within the log data from destroying the layout
* Dev: Add the $user variable to the do_action argument for the get_user webhook action
* Dev: Add the $return_args variable to the do_action argument for the create_post webhook action

= 3.0.1: March 08, 2020 =
* Feature: New webhook trigger setting to change the request method. Supported: POST (Default), GET, HEAD, PUT, DELETE, TRACE, OPTIONS, PATCH
* Tweak: Optimize certain layout parts 
* Tweak: Display webhook name and technical name within the Settings popup
* Fix: On reset of WP Webhooks Pro, the authentication data was not removed
* Fix: meta values that should be serialized from a JSON haven't been serialized properly. 
* Dev: Deprecated trigger secret (Can be set only with WordPress hooks) - Why? Due to confusion and too specific usecases

= 3.0.0: February 10, 2020 =
* Feature: THIS VERSION IS FULLY BACKWARDS COMPATIBLE
* Feature: Completely refactored any optimized layout
* Feature: GET parameters are now accepted as well as action arguments (Only in real GET calls)
* Feature: New authentication engine: You can now authenticate every webhook trigger for external APIS using API Key, Bearer Token or Basic Auth
* Feature: New webhook action called "custom_action", which allows you to handle every incoming data within a WordPress add_action() hook
* Feature: Change the webhook URL you want to use for testing actions within the "Receive Data" page
* Feature: Custom tag system to map other Payload fields together to a single string within the Data Mapping Engine
* Tweak: Added the action argument as well the the argument list within the "Receive Data" tab
* Tweak: Added the action argument as well to the testing form for webhook actions within the "Receive Data" tab
* Tweak: Completely refactored settings saving process for a smooth UI experience
* Tweak: PHP Docs have been optimized
* Tweak: Placeholder logic is not integrated with dynamic settings fields for "Send Data" settings
* Tweak: Whitelist has now as well a beautified version for displaying JSON data
* Tweak: The webhook triggers within the "Send Data" tab show now as well the internal webhook name (in brackets)
* Tweak: We changed all checkboxes through neat toggles for a better usability
* Tweak: Optimize layout for Helpers Tags on Data Mapping Page
* Tweak: Rearrange setting items
* Fix: API key field was missing after adding a new action URL
* Fix: Corrected certain typos
* Dev: Added new filter to manipulate post-delayed triggers: ww/post_delay/post_delay_triggers (Prevent webhook triggers from firing or add your own ones)
* Dev: Add multiple arguments to the post_to_webhook()-functions WordPress actions
* Dev: ww/admin/webhooks/webhook_http_args has now two more arguments: $webhook, $authentication_data
* Dev: ww/admin/webhooks/webhook_trigger_sent has now more arguments

= 2.2.0: January 28, 2020 =
* Fix: Throw 403 http error accordingly on authentications
* Tweak: Optimize error messages for authentication

= 2.1.9: January 27, 2020 =
* Feature: Import/Export of Data Mapping templates
* Feature: The webhook authentication process is now also fully JSON ready and returns a JSON as a response
* Tweak: A failed authentication now also returns a 200 error code instead of 403 
* Tweak: Settings layout is now better readable

= 2.1.8: January 17, 2020 =
* Feature: Allow the custom webhook trigger to send data only to certain webhooks using the secondary $webhook_names variable: do_action( 'wp_webhooks_send_to_webhook', $custom_data, $webhook_names );
* Tweak: Add $update variable to "do_action" argument of the update_user endpoint
* Tweak: Optimize webhook descriptions for certain triggers and actions
* Fix: Correct password creation logic for creating a user
* Fix: Triggers didn't fire on creating or updating an attachment
* Fix: Generate password as well on user_update if user does not exist and create_if_none is set to yes
* Fix: The custom action trigger contained a custom action that was fired as well on post deletion

= 2.1.7: December 16, 2019 =
* Feature: Display new table field for only the API key
* Feature: Added new webhook trigger that fires after a user was deleted
* Tweak: Better support for our new Zapier App 2.0.0

= 2.1.6: November 27, 2019 =
* Feature: Send post taxonomies along with post creade and update trigger
* Tweak: Clear input fields after adding new trigger
* Tweak: Update plugin updater class

= 2.1.5: November 15, 2019 =
* Feature: Activate/Deactivate single webbhook triggers
* Feature: Post-delay webhook triggers. (Triggers are fired before PHP shuts down to catch plugin changes)
* Feature: Post-delay setting to deactivate the functionality
* Tweak: Optimize PHPDocs

= 2.1.4: November 06, 2019 =
* Feature: Add webhook name field (slug) to the webhook trigger URL's
* Feature: Add webhook name to the webhook trigger headers
* Tweak: Add additional parameters to the authorization hook
* Tweak: Optimize webhook description for "get_user" action
* Fix: Get user response gave success back if no user was found
* Fix: Create user on update_user webhook doesn't work properly
* Dev: Adjust WordPress hook priority for incoming data from 10 to 100 

= 2.1.2: October 20, 2019 =
* Feature: Introduce exclusive Zapier extension (Early access)
* Feature: Introduce new polling feature for next-level Zapier triggers

= 2.1.1: October 12, 2019 =
* Fix: Bump new version to readme and main files

= 2.1.0: October 12, 2019 =
* Feature: Deactivate and Activate webhook action URL's
* Feature: Add the previous post data to the "Send Data on Post Update" trigger response
* Feature: New webhook actions to search/retrieve post(s) within a third party services
* Feature: New webhook actions to search/retrieve user(s) within a third party services
* Teak: Optimized and simplified backend layout
* Tweak: Add webhook name for action and triggers to the webhook settings as data itself (This allows better targeting of webhook manipulations)
* Tweak: Add webhook name to every single log within out logging feature
* Tweak: Include fallback logic for non-working JSON contructs that include unicode characters
* Tweak: Optimize packend docs and WordPress code standards
* Fix: Remove unncessary var_dump()-calls within our backend tabs

= 2.0.5: August 31, 2019 =
* Feature: Protect your webhook actions using an access token
* Feature: Support Woocommerce post status on default post status features like sending a trigger on post creation with a certain status
* Tweak: Correct management of post and user meta values to also send them within the triggers as existing meta values
* Tweak: Made action_delete_user function public
* Fix: Fixed bug with non-working do_action parameter on create/update user action
* Fix: Issue with non working "Send data on user login" due to wrong interpreted user parameter
* Dev: New filter for webhook trigger data: ww/admin/webhooks/webhook_data

= 2.0.4: August 09, 2019 =
* Feature: Trigger create_post webhook if the initial status of the post changes
* Tweak: Optimize PHPDocs
* Fix: Non-working action testing forms in case https was active
* Dev: New helper function for safe-redirecting the home url
* Dev: Optimize WordPress coding standards

= 2.0.3: August 01, 2019 =
* Tweak: Added phpdocs for data mapping template
* Tweak: Optimize meta value sanitation for allowing a bigger variety of values
* Fix: Correct description of trigger setting for frontend limitations

= 2.0.2: July 26, 2019 =
* Feature: Allow user deletion from whole multisite network
* Feature: Add post author to create/update post action with the user id OR the email address
* Tweak: Optimize webhook descriptions

= 2.0.1: June 30, 2019 =
* Fix: When using update_user action in combination with create_if_none, the user was not aadded

= 2.0.0: June 30, 2019 =
* Feature: Webhook actions are ajax ready
* Feature: Data Mapping Engine to change data keys for triggers and actions and create new values
* Feature: Settings Engine for webhook actions
* Feature: Complete overhaul for the log functionality
* Feature: Security question before deleting an action or trigger
* Fix: Fix text bugs
* Fix: Debug warning if json data is parsed as an array and not as a string
* Fix: Solve bug with not read user meta data when raw json is given
* Fix: Fix issue with not correctly applied text domain for translation functions
* Fix: Non existent translation within the Send Data Tab for the "Add button"
* Dev: New filter ww/helpers/request_return_value
* Dev: New filter ww/settings/required_action_settings
* Dev: New filter ww/admin/settings/data_mapping_table_data
* Dev: New action ww/admin/webhooks/webhook_action_after_settings

= 1.6.7: May 31, 2019 =
* Feature: Add and remove multiple user roles while creating or updating a user
* Feature: Define a webhook action directly within the webhook URL by adding &action=MYCUSTOMWEBHOOK. E.g.: https://mydomain.com/?ww_action=XXX&ww_api_key=XXX&action=create_post
* Tweak: Optimize PHPDocs
* Fix: While updating a user without defining the email specificly, the email was removed

= 1.6.6: May 25, 2019 =
* Tweak: Remove strip slashes settings item (It's not too common so we use only the filter instead)

= 1.6.5: May 23, 2019 =
* Feature: Send your triggers in different content types. Supported types: JSON (Default), XML, X-WWW-FORM-URLENCODE
* Feature: Create serialized arrays as post meta values for users and posts on the following actions: create_user, create_post, update_user, update_post
* Fix: Correct menu item name from "Receive Data" to "Receive Data"
* Fix: Remove sanitation from parsed user password to not change it at all (create_user and update_user trigger)
* Dev: New filter to strip slashes on responses: ww/helpers/request_values_stripslashes
* Dev: New filter for the new convert_to_xml function to change the prefix: ww/helpers/convert_to_xml_int_prefix
* Dev: Filter for manipulating the required webhook trigger settings: ww/settings/required_trigger_settings
* Dev: Filter to change the simplexml data: ww/admin/webhooks/simplexml_data

= 1.6.4: April 24, 2019 =
* Feature: Introduce new webhook trigger settings - You can now set custom rules for each of your webhook triggers
* Feature: Confirm action before deleting a trigger webhook
* Feature: Reset WP Webhook data via the settings
* Feature: Added a new webhook trigger that fires after a custom WordPress action hook was called. ( Send Data On Custom Action )
* Feature: Introduce new default settings for the following webhooks: Send Data On New Post, Send Data On Post Update, Send Data On Post Deletion
* Feature: Introduce new settings to fire a trigger only on certain post types for the following webhooks: Send Data On New Post, Send Data On Post Update, Send Data On Post Deletion
* Tweak: Add post data and post meta data to the post_delete trigger
* Tweak: Optimize process for generated webhook trigger id's
* Tweak: Change post_delete trigger from after_delete_post to delete_post
* Tweak: Optimize response for custom action after certain webhooks
* Tweak: Optimize phpDocs
* Tweak: Optimize Send Data tab
* Tweak: Improve the displayed values for single webhook trigger responses
* Fix: Fix issue of not visible whitelist and log tabs after saving the settings
* Dev: Introduce optimized handler for posting data to a webhook. You can now also parse the whole webhook array construct
* Dev: Add new webhook default settings api
* Dev: Add new webhook settings api
* Dev: Introduce new update function for updating webhook data

= 1.6.3: April 13, 2019 =
* Feature: Webhook log - Display send and received requests
* Feature: Optimized headers for "Send Data" triggers
* Feature: Add Signature for "Send Data" triggers through new settings option
* Tweak: Optimize backend layout#
* Dev: Add new filter ww/admin/webhooks/get_hooks for filtering active webhooks
* Dev: Add new filter ww/admin/webhooks/webhook_http_args for filtering the "Send Data" http arguments
* Dev: Add new action ww/admin/webhooks/webhook_trigger_sent after a trigger was sent

= 1.6.2: March 23, 2019 =
* Tweak: Better plugin initialization
* Tweak: Optimize text

= 1.6.1: March 20, 2019 =
* Feature: Test the webhook directly out of the plugin
* Feature: Return the action name in case no webhook is set for a better debugging
* Tweak: Add new license expired notice
* Dev: Add filter for the response body (The data that gets send back to the webhook caller)

= 1.6.0: March 9, 2019 =
* Fix: Home content was displayed when custom settings page was registered
* Fix: Fatal error on some plugin activations: Fatal error: Can't use method return value in write context

= 1.5.9: March 1, 2019 =
* Feature: Add our new Assistant Bot to our plugin. It will help you to solve tons of things directly from your dashboard.
* Feature: New action webhook to test fucntionality.

= 1.5.8: February 28, 2019 =
* Feature: New response field inside of actions to see what data you can expect to come back.
* Feature: New sent data field inside of triggers to see which data gets send after a trigger fires.
* Feature: Allow JSON for custom user meta and post meta for a better handling of complex values.
* Tweak: Optimized Response data for a clearer overview (Please make sure you check your webhooks before updating)
* Tweak: Compatibility handler for not correctly set SERVER_NAME var in $_SERVER while grabbing the current url
* Tweak: Optimized Performance
* Tweak: Optimized PHPDocs for various functions
* Tweak: Add user meta to create and update user response
* Tweak: Add post meta and tax inout to create and update post reponse
* Fix: Correct wording issues
* Fix: force_delete for post delete response returned post id instead of boolean
* Dev: New hook ww/webhooks/response_json_arguments (https://ironikus.com/docs/knowledge-base/filter-response-arguments/)
* Dev: New hook ww/webhooks/response_response_type (https://ironikus.com/docs/knowledge-base/filter-response-type/)
* Dev: New hook ww/admin/webhooks/default_webhook_name (https://ironikus.com/docs/knowledge-base/default-webhook-name/)

= 1.5.7: February 12, 2019 =
* Feature: Add whitelist feature for enhanced security
* Feature: Add support for xml response
* Feature: Add $response_data to user various trigger wp hooks
* Tweak: Optimized license handler
* Tweak: Optimize settings tab
* Tweak: Optimize updater class
* Tweak: Validate action nonce data
* Tweak: Optimize code quality and PHPDocs
* Fix: Issue with displaying changes on main plugin update page
* Fix: Set specified content type header on dynamic request type
* Fix: Plugin updater issue (On multisites the updater didn't work)
* Fix: Undefined notice with certain configurations of plugin data for the delete_post action webhook

= 1.5.6: January 27, 2019 =
* Fix: Correct version values

= 1.5.5: January 27, 2019 =
* Tweak: Introduce new updater handler for extensions
* Tweak: Optimize invalid/inactive license notifications
* Tweak: Change namespace definitions
* Tweak: Optimize PHPDocs

= 1.5.4: January 26, 2019 =
* Feature: Add support for application/json
* Feature: Add support for application/xml
* Feature: Add support for x-www-form-urlencoded (native)
* Feature: Add support for text/html via our new tag engine
* Feature: Add support for text/plain via our new tag engine
* Feature: Add new tag engine for text and html validation


= 1.5.3: January 23, 2019 =
* Feature: Add new taxonomy create/delete framework to create_post and update_post
* Feature: New possibility to create a user on update if it doesn't exist as an attribute
* Feature: Create better response for the create post and update post trigger (Send Data)
* Feature: Create better response for the create post and update post action (Receive Data)
* Feature: Add error data to action response on update_user
* Tweak: Optimize some functions for a better WordPress standard
* Tweak: New handling of various key components for actions ($_GET)
* Tweak: Optimize Rich editing value
* Tweak: Optimize short description of the update_post action (Receive data)
* Tweak: Optimize description of the delete_user action (Receive data)
* Tweak: Optimize short description of the create_post action (Receive data)
* Dev: Add functionality for parsing custom arguments to the post_to_webhook function for wp_remote_post
* Fix: Remove PHP Notice when no webhook is set for some send_data actions
* Fix: Webhook action urls were not deletable
* Fix: Create different response message for updated user action (Receive Data)
* Fix: When a post was set to update_post and create_if_none was true, then it always created a new post
* Fix: Correct and optimize webhook descriptions
* Fix: Fix issue with deleting a user if an email is given instead of a user id

= 1.5.2: January 15, 2019 =
* Tweak: Include fallback response if an action is not set or the action function is missing
* Tweak: Optimize PHPDocs and the documentation in general
* Tweak: Include new UTM Links
* Tweak: Improve way of providing response json (die)
* Fix: Fix issue with deleting posts
* Fix: Clear issue with undefined indec notice for triggers if no trigger is set
* Fix: Undefined index notice after a license was not available anymore
* Fix: corrected wrongly spelled words
* Fix: Response issue on some action requests

= 1.5.1: January 13, 2019 =
* Feature: New function for creating an automated username via the create_user webhook
* Feature: Global handler for action response json (Now we validate the response as a json with multiple data fields.
* Tweak: Optimized PHPDocs and better webhook descriptions
* Tweak: Optimize demo request functions
* Fix: Issue with post_category that just allows a single category to be set
* Fix: Multiple small bugfixes like text bugs and formatting issues

= 1.5: January 13, 2019 =
* Feature: Add new actions for create, update and delete posts
* Tweak: Update WordPress "Tested up to" to 5.0.3
* Fix: Correct naming of PHPDocs

= 1.4: December 26, 2018 =
* Feature: Introduce transients for home screen api calls
* Feature: Include a new tag validation function
* Tweak: Update WordPress "Tested up to" to 5.0.2
* Tweak: Optimize existing action descriptions
* Fix: Fix wrongly loaded home screen api

= 1.3: December 25, 2018 =
* Fix: Clear issue with admin related webhook calls
* Fix: Call actions for validating incoming data directly

= 1.2: November 30, 2018 =
* Fix: Remove issue with webhook unset function
* Fix: Update Code for better WordPress Coding Standards
* Fix: Update various links to our Documentation
* Fix: Globalize translation identifier for single page tabs
* Fix: Display plugin title on admin page
* Tweak: Better layout for an easier usage
* Feature: Introduce Settings page
* Feature: Setting for activating translations engine
* Feature: Webhook Control via Settings page (Activate only the features you want)
* Feature: Add new trigger for creating, updating and deleting a post (Works also for custom post types)

= 1.1: November 18, 2018 =
* Fix: Remove issue with webhook unset function
* Fix: issue with recieving actions from various webhooks
* Fix: issue with the api_key action parameter
* Tweak: Optimize performance for validating default webhooks
* Tweak: Make user_login field optional for new users (If not defined, we use the sanitized user email)

= 1.0: November 10, 2018 =
* Birthday of WP Webhooks Pro
