<h2>    Extensions for WordPress Webhooks </h2>

<div>
This page contains all approved extensions for <strong>WordPress Webhooks</strong>. You will be able to fully manage each of the extensions right within this plugin. In case you want to list your very own plugin here, feel free to <a title="Go to our contact form" target="_blank" href="#">reach out to us</a>.    </div>
<div class="wpwh-extensions-wrapper">

<div class="card single-extension" style="width: 18rem;">
<img src="<?php echo WW_PLUGIN_URL . 'includes/frontend/assets/img/Woocommerce-Integration-min.jpg'; ?>">

<div class="card-body">
<small>v1.0.5</small>
<h5 class="card-title">
<span class="golden">Pro</span> 


Woocommerce Integration                    </h5>

<div class="d-flex flex-column">
<a href="#" target="_blank" class="btn btn-info more-info">Premium</a>


<a class="btn btn-secondary h30 ironikus-extension-manage" href="http://localhost/wordpress_sites/firsttheme/wp-admin/options-general.php?page=wp-webhooks-pro&amp;tab=license" title="Activate your licene first">
Coming soon                            </a>

<div class="bottom-action-wrapper">
</div>
</div>

<div class="card-footer">
Made by Pull Bytes
</div>
</div>

</div>        </div>

